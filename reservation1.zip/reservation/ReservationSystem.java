import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ReservationSystem extends JFrame {

    private Map<String, String> userCredentials;
    private Map<String, ArrayList<String>> reservations;

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextArea reservationTextArea;

    public ReservationSystem() {
        super("Online Reservation System");

        userCredentials = new HashMap<>();
        reservations = new HashMap<>();

        // Sample user credentials
        userCredentials.put("user1", "password1");

        setLayout(new FlowLayout());

        // Login Form
        JPanel loginPanel = new JPanel(new GridLayout(3, 2));
        JLabel usernameLabel = new JLabel("Username:");
        JLabel passwordLabel = new JLabel("Password:");
        usernameField = new JTextField(10);
        passwordField = new JPasswordField(10);
        JButton loginButton = new JButton("Login");

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });

        loginPanel.add(usernameLabel);
        loginPanel.add(usernameField);
        loginPanel.add(passwordLabel);
        loginPanel.add(passwordField);
        loginPanel.add(new JLabel());
        loginPanel.add(loginButton);

        // Reservation System
        JPanel reservationPanel = new JPanel(new BorderLayout());
        reservationTextArea = new JTextArea(10, 20);
        reservationTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(reservationTextArea);
        JButton reserveButton = new JButton("Reserve");
        JButton cancelReservationButton = new JButton("Cancel Reservation");

        reserveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                reserve();
            }
        });

        cancelReservationButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cancelReservation();
            }
        });

        reservationPanel.add(scrollPane, BorderLayout.CENTER);
        reservationPanel.add(reserveButton, BorderLayout.SOUTH);
        reservationPanel.add(cancelReservationButton, BorderLayout.NORTH);

        add(loginPanel);
        add(reservationPanel);

        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void login() {
        String username = usernameField.getText();
        char[] password = passwordField.getPassword();
        String passwordStr = new String(password);

        if (userCredentials.containsKey(username) && userCredentials.get(username).equals(passwordStr)) {
            displayReservations(username);
        } else {
            JOptionPane.showMessageDialog(this, "Invalid username or password", "Login Error", JOptionPane.ERROR_MESSAGE);
        }

        // Clear fields
        usernameField.setText("");
        passwordField.setText("");
    }

    private void displayReservations(String username) {
        if (reservations.containsKey(username)) {
            ArrayList<String> userReservations = reservations.get(username);
            StringBuilder reservationText = new StringBuilder("Your Reservations:\n");

            for (String reservation : userReservations) {
                reservationText.append(reservation).append("\n");
            }

            reservationTextArea.setText(reservationText.toString());
        } else {
            reservationTextArea.setText("No reservations for this user.");
        }
    }

    private void reserve() {
        String username = usernameField.getText();

        if (!reservations.containsKey(username)) {
            reservations.put(username, new ArrayList<>());
        }

        String reservationDetails = JOptionPane.showInputDialog(this, "Enter reservation details:");
        reservations.get(username).add(reservationDetails);

        displayReservations(username);
    }

    private void cancelReservation() {
        String username = usernameField.getText();

        if (reservations.containsKey(username) && !reservations.get(username).isEmpty()) {
            int selectedIndex = JOptionPane.showOptionDialog(this,
                    "Select reservation to cancel:",
                    "Cancel Reservation",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    reservations.get(username).toArray(),
                    reservations.get(username).get(0));

            if (selectedIndex != JOptionPane.CLOSED_OPTION) {
                reservations.get(username).remove(selectedIndex);
                displayReservations(username);
            }
        } else {
            JOptionPane.showMessageDialog(this, "No reservations to cancel", "Cancel Reservation", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ReservationSystem();
            }
        });
    }
}

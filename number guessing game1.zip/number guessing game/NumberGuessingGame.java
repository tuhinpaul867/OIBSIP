import java.awt.*;
import java.util.Random;

public class NumberGuessingGame extends Frame {

    private TextField guessField;
    private Button guessButton;
    private Label feedbackLabel;
    private int randomNumber;

    public NumberGuessingGame() {
        super("Number Guessing Game");

        // Create the GUI components
        guessField = new TextField(10);
        guessButton = new Button("Guess");
        feedbackLabel = new Label("");

        // Add the GUI components to the frame
        add(guessField);
        add(guessButton);
        add(feedbackLabel);

        // Set the layout of the frame
        setLayout(new FlowLayout());

        // Register the guessButton listener
        guessButton.addActionListener(e -> guess());

        // Generate a random number
        randomNumber = new Random().nextInt(100) + 1;

        // Set the size and visibility of the frame
        setSize(300, 100);
        setVisible(true);
    }

    private void guess() {
        // Get the user's guess
        int guess = Integer.parseInt(guessField.getText());

        // Check if the guess is correct
        if (guess == randomNumber) {
            feedbackLabel.setText("Correct! You guessed the number!");
        } else if (guess < randomNumber) {
            feedbackLabel.setText("Too low!");
        } else {
            feedbackLabel.setText("Too high!");
        }
    }

    public static void main(String[] args) {
        new NumberGuessingGame();
    }
}